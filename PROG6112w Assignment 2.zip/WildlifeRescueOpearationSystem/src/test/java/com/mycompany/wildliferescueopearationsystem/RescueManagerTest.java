/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



/**
 *JUnit 5 Test for Wildlife Rescue Operations System.
 * Tests class constructors, cost calculations, priority rules,
 * status changes, duplicate ID checking, and search logic.
 * 
 * @author prude
 */
public class RescueManagerTest {

    private RescueManager manager;

    @BeforeEach
    public void setUp() {
        manager = new RescueManager();
    }

    // --- 1. TESTS FOR INJURED ANIMAL RESCUE ---

    @Test
    public void testInjuredAnimalRescueCostWithSurgery() {
        // 5 days * R500/day (2500) + R13000 vet + R2500 surgery = R18000
        InjuredAnimalRescue injured = new InjuredAnimalRescue(
            "WR121", "Leo", "African Elephant", "Phalaborwa", "Ranger Solomon", 
            5, 500.0, "Leg Injury", 13000.0, true
        );
        assertEquals(18000.0, injured.calculateTotalRescueCost(), 0.01);
    }

    @Test
    public void testInjuredAnimalRescueCostWithoutSurgery() {
        // 4 days * R300/day (1200) + R2000 vet + R0 surgery = R3200
        InjuredAnimalRescue injured = new InjuredAnimalRescue(
            "WR122", "Simba", "Lion", "Kruger National Park", "Ranger Pheladi", 
            4, 300.0, "Minor Cut", 2000.0, false
        );
        assertEquals(3200.0, injured.calculateTotalRescueCost(), 0.01);
    }

    @Test
    public void testInjuredAnimalPriorityCritical() {
        InjuredAnimalRescue injured = new InjuredAnimalRescue(
            "WR123", "Leo", "African Elephant", "Phalaborwa", "Ranger Solomon", 
            5, 500.0, "Leg Injury", 13000.0, true
        );
        injured.determineRescuePriority();
        assertEquals("Critical", injured.getRescuePriority());
    }

    // --- 2. TESTS FOR ORPHANED ANIMAL RESCUE ---

    @Test
    public void testOrphanedAnimalRescueCostWithFosterCare() {
        // 10 days * R400/day (4000) + R5000 feeding + R1500 foster = R10500
        OrphanedAnimalRescue orphan = new OrphanedAnimalRescue(
            "WR124", "Milo", "White Rhino", "Phalaborwa", "Ranger Kgotso", 
            10, 400.0, 2, 5000.0, true
        );
        assertEquals(10500.0, orphan.calculateTotalRescueCost(), 0.01);
    }

    @Test
    public void testOrphanedAnimalPriorityHighForYoungAge() {
        // Age <= 3 months triggers High priority
        OrphanedAnimalRescue orphan = new OrphanedAnimalRescue(
            "WR125", "Milo", "White Rhino", "Phalaborwa", "Ranger Kgotso", 
            10, 400.0, 2, 5000.0, false
        );
        orphan.determineRescuePriority();
        assertEquals("High", orphan.getRescuePriority());
    }

    // --- 3. TESTS FOR ENDANGERED SPECIES RESCUE ---

    @Test
    public void testEndangeredSpeciesRescueCostWithSpecialistTeam() {
        // 7 days * R600/day (4200) + R8000 security + R3000 specialist = R15200
        EndangeredSpeciesRescue endangered = new EndangeredSpeciesRescue(
            "WR126", "Zara", "Cheetah", "Hoedspruit", "Ranger Lerato", 
            7, 600.0, "Critically Endangered", 8000.0, true
        );
        assertEquals(15200.0, endangered.calculateTotalRescueCost(), 0.01);
    }

    @Test
    public void testEndangeredSpeciesPriorityCritical() {
        EndangeredSpeciesRescue endangered = new EndangeredSpeciesRescue(
            "WR127", "Zara", "Cheetah", "Hoedspruit", "Ranger Lerato", 
            7, 600.0, "Critically Endangered", 8000.0, false
        );
        endangered.determineRescuePriority();
        assertEquals("Critical", endangered.getRescuePriority());
    }

    // --- 4. TESTS FOR RESCUE MANAGER & SEARCH LOGIC ---

    @Test
    public void testAddAndSearchRescueCase() {
        InjuredAnimalRescue case1 = new InjuredAnimalRescue(
            "WR128", "Leo", "African Elephant", "Phalaborwa", "Ranger Solomon", 
            5, 500.0, "Leg Injury", 13000.0, true
        );
        manager.addRescueCase(case1);
        
        
        RescueCase foundCase = manager.searchRescueCase("WR128");
        assertNotNull(foundCase);
        assertEquals("Leo", foundCase.getAnimalName());
    }

    @Test
    public void testDuplicateIdDetection() {
        InjuredAnimalRescue case1 = new InjuredAnimalRescue(
            "WR129", "Leo", "African Elephant", "Phalaborwa", "Ranger Solomon", 
            5, 500.0, "Leg Injury", 13000.0, true
        );
        manager.addRescueCase(case1);

        assertTrue(manager.isIdDuplicate("WR129"));
        assertFalse(manager.isIdDuplicate("WR999"));
    }

    // --- 5. TESTS FOR STATUS TRANSITIONS ---

    @Test
    public void testRescueStatusTransitions() {
        InjuredAnimalRescue case1 = new InjuredAnimalRescue(
            "WR130", "Leo", "African Elephant", "Phalaborwa", "Ranger Solomon", 
            5, 500.0, "Leg Injury", 13000.0, true
        );
        assertEquals("Pending", case1.getCurrentRescueStatus());

        case1.startRescueOperation();
        assertEquals("Rescue in Progress", case1.getCurrentRescueStatus());

        case1.completeRescueOperation();
        assertEquals("Completed", case1.getCurrentRescueStatus());
    }
}