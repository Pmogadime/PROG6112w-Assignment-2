/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

/**
 *
 * @author prude
 */
  
// Subclass for managing endangered species protection cases
public class EndangeredSpeciesRescue extends RescueCase {

    // Specific attributes for conservation and security
    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    // Constructor initializing shared and subclass attributes
    public EndangeredSpeciesRescue(String rescueCaseId, String animalName, String species, 
                                   String rescueLocation, String assignedRanger, 
                                   int numberOfRescueDays, double dailyCareCost, 
                                   String conservationClassification, double securityCost, 
                                   boolean specialistTeamRequired) {
        super(rescueCaseId, animalName, species, rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    // Calculates base care cost + security cost + optional R3,000 specialist fee
    @Override
    public double calculateTotalRescueCost() {
        double baseCost = getNumberOfRescueDays() * getDailyCareCost();
        double extraSpecialistFee = specialistTeamRequired ? 3000.0 : 0.0;
        return baseCost + securityCost + extraSpecialistFee;
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    // Assigns priority based on threat classification and specialist needs
    @Override
    public void determineRescuePriority() {
        if (conservationClassification.equalsIgnoreCase("Critically Endangered") || specialistTeamRequired) {
            setRescuePriority("Critical");
        } else {
            setRescuePriority("High");
        }
    }

    // Appends security and status breakdown to the main summary
    @Override
    public String generateRescueSummary() {
        return super.generateRescueSummary() + String.format(
            "\nClassification : %s" +
            "\nSpecialist Team: %s" +
            "\nSecurity Cost  : R%.2f" +
            "\nTotal Cost     : R%.2f",
            conservationClassification, (specialistTeamRequired ? "Yes" : "No"), securityCost, calculateTotalRescueCost()
        );
    }

    // Getters
    public String getConservationClassification() { return conservationClassification; }
    public double getSecurityCost() { return securityCost; }
    public boolean isSpecialistTeamRequired() { return specialistTeamRequired; }
}