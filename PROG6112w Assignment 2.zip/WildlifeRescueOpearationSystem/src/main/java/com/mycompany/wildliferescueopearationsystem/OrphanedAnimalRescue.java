/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

/**
 *
 * @author prude
 */

// Subclass for managing orphaned animal rescue cases
public class OrphanedAnimalRescue extends RescueCase {

    // Specific attributes for nursery and juvenile care
    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    // Constructor initializing shared and subclass attributes
    public OrphanedAnimalRescue(String rescueCaseId, String animalName, String species, 
                                String rescueLocation, String assignedRanger, 
                                int numberOfRescueDays, double dailyCareCost, 
                                int estimatedAgeMonths, double feedingCost, 
                                boolean fosterCareRequired) {
        super(rescueCaseId, animalName, species, rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    // Calculates base care cost + feeding cost + optional R1,500 foster fee
    @Override
    public double calculateTotalRescueCost() {
        double baseCost = getNumberOfRescueDays() * getDailyCareCost();
        double extraFosterFee = fosterCareRequired ? 1500.0 : 0.0;
        return baseCost + feedingCost + extraFosterFee;
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    // Assigns priority based on age vulnerability and care needs
    @Override
    public void determineRescuePriority() {
        if (estimatedAgeMonths <= 3 || fosterCareRequired) {
            setRescuePriority("High");
        } else {
            setRescuePriority("Medium");
        }
    }

    // Appends nursery care breakdown to the main summary
    @Override
    public String generateRescueSummary() {
        return super.generateRescueSummary() + String.format(
            "\nAge (Months)   : %d" +
            "\nFoster Care    : %s" +
            "\nFeeding Cost   : R%.2f" +
            "\nTotal Cost     : R%.2f",
            estimatedAgeMonths, (fosterCareRequired ? "Yes" : "No"), feedingCost, calculateTotalRescueCost()
        );
    }

    // Getters
    public int getEstimatedAgeMonths() { return estimatedAgeMonths; }
    public double getFeedingCost() { return feedingCost; }
    public boolean isFosterCareRequired() { return fosterCareRequired; }
}