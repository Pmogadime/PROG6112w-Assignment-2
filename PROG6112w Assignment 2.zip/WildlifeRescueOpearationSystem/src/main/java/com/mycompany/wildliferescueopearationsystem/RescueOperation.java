/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

/**
 *
 * @author prude
 */
// Interface defining the essential operations required for all rescue operations
public interface RescueOperation {
    // Starts the rescue operation and updates status
    void startRescueOperation();
    
    // Completes the rescue operation and updates status
    void completeRescueOperation();
    
    // Formats and returns a summary of the rescue case
    String generateRescueSummary();
}
    

