/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

/**
 *
 * @author prude
 */

//Abstract base class representing a general rescue case 
public abstract class RescueCase implements RescueOperation {
    // Shared attributes across all rescue case types
    private String rescueCaseId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int numberOfRescueDays;
    private double dailyCareCost;
    private String currentRescueStatus;
    private String rescuePriority;

    // Constructor to initialize standard rescue case attributes
    public RescueCase(String rescueCaseId, String animalName, String species, 
                      String rescueLocation, String assignedRanger, 
                      int numberOfRescueDays, double dailyCareCost) {
        this.rescueCaseId = rescueCaseId;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.numberOfRescueDays = numberOfRescueDays;
        this.dailyCareCost = dailyCareCost;
        this.currentRescueStatus = "Pending"; // Default initial status
        this.rescuePriority = "Medium";       // Default priority
    }

    // Abstract methods to be implemented by specific subclasses
    public abstract double calculateTotalRescueCost();
    public abstract String getRescueType();
    public abstract void determineRescuePriority();

    // Interface method implementation to start the operation
    @Override
    public void startRescueOperation() {
        this.currentRescueStatus = "Rescue in Progress";
    }

    // Interface method implementation to mark the operation as complete
    @Override
    public void completeRescueOperation() {
        this.currentRescueStatus = "Completed";
    }

    // Base summary formatted output
    @Override
    public String generateRescueSummary() {
        determineRescuePriority(); // Recalculate priority before returning summary
        return String.format(
            "Case ID        : %s\n" +
            "Type           : %s\n" +
            "Animal Name    : %s\n" +
            "Species        : %s\n" +
            "Location       : %s\n" +
            "Assigned Ranger: %s\n" +
            "Priority       : %s\n" +
            "Status         : %s\n" +
            "Rescue Days    : %d\n" +
            "Daily Care Cost: R%.2f",
            rescueCaseId, getRescueType(), animalName, species, rescueLocation, 
            assignedRanger, rescuePriority, currentRescueStatus, 
            numberOfRescueDays, dailyCareCost
        );
    }

    // Getter and Setter methods for encapsulated private fields
    public String getRescueCaseId() { return rescueCaseId; }
    public String getAnimalName() { return animalName; }
    public String getSpecies() { return species; }
    public String getRescueLocation() { return rescueLocation; }
    public String getAssignedRanger() { return assignedRanger; }
    public int getNumberOfRescueDays() { return numberOfRescueDays; }
    public double getDailyCareCost() { return dailyCareCost; }
    public String getCurrentRescueStatus() { return currentRescueStatus; }
    public void setCurrentRescueStatus(String currentRescueStatus) { this.currentRescueStatus = currentRescueStatus; }
    public String getRescuePriority() { return rescuePriority; }
    public void setRescuePriority(String rescuePriority) { this.rescuePriority = rescuePriority; }
}