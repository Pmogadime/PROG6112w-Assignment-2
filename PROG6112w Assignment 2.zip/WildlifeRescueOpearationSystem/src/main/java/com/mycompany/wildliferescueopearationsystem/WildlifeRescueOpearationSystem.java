/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.wildliferescueopearationsystem;
 import java.util.Scanner;

/**
 *
 * @author prude
 */
// Main entry point class managing user interactions and menu prompts
public class WildlifeRescueOpearationSystem {

    private static RescueManager manager = new RescueManager();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Pre-populate sample test data
        manager.addRescueCase(new InjuredAnimalRescue("WR121", "Luna", "African Elephant", "Kruger National Park", "Ranger Solomon", 5, 500.0, "Leg Injury", 13000.0, true));
        manager.addRescueCase(new OrphanedAnimalRescue("WR122", "Cairo", "White Rhino", "Phalaborwa", "Ranger Kgotso", 10, 400.0, 2, 5000.0, true));

        boolean exit = false;
        // Main application menu loop
        while (!exit) {
            displayMenu();
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    createRescueCase();
                    break;
                case "2":
                    searchRescueCase();
                    break;
                case "3":
                    updateRescueStatus();
                    break;
                case "4":
                    displayAllCases();
                    break;
                case "5":
                    filterCasesByProgress();
                    break;
                case "6":
                    System.out.println("\n" + manager.generateFullReport());
                    break;
                case "7":
                    exit = true;
                    System.out.println("Exiting Wildlife Rescue Operations System. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option selected. Please enter a number between 1 and 7.");
            }
        }
    }

    // Prints main command menu
    private static void displayMenu() {
        System.out.println("\n==================================================");
        System.out.println("WILDLIFE RESCUE OPERATIONS SYSTEM");
        System.out.println("==================================================");
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status (Progress Tracking)");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Track Cases by Progress Status");
        System.out.println("6. Rescue Report");
        System.out.println("7. Exit");
        System.out.print("\nSelect an option: ");
    }

    // Prompt user to enter data and instantiate new rescue case
    private static void createRescueCase() {
        System.out.println("\n--- Create New Rescue Case ---");
        String id = getNonBlankInput("Enter Rescue Case ID: ");
        if (manager.isIdDuplicate(id)) {
            System.out.println("Error: A rescue case with ID '" + id + "' already exists.");
            return;
        }

        String animalName = getNonBlankInput("Enter Animal Name: ");
        String species = getNonBlankInput("Enter Species: ");
        String location = getNonBlankInput("Enter Rescue Location: ");
        String ranger = getNonBlankInput("Enter Assigned Ranger: ");
        int days = getPositiveIntInput("Enter Number of Rescue Days: ");
        double dailyCost = getPositiveDoubleInput("Enter Daily Care Cost (R): ");

        System.out.println("\nSelect Rescue Type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");
        System.out.print("Select type (1-3): ");
        String typeOption = scanner.nextLine().trim();

        RescueCase newCase = null;

        switch (typeOption) {
            case "1":
                String injury = getNonBlankInput("Enter Injury Description: ");
                double vetCost = getPositiveDoubleInput("Enter Veterinary Treatment Cost (R): ");
                boolean surgery = getBooleanInput("Is surgery required? (yes/no): ");
                newCase = new InjuredAnimalRescue(id, animalName, species, location, ranger, days, dailyCost, injury, vetCost, surgery);
                break;
            case "2":
                int age = getPositiveIntInput("Enter Estimated Age in Months: ");
                double feedingCost = getPositiveDoubleInput("Enter Feeding Cost (R): ");
                boolean foster = getBooleanInput("Is foster care required? (yes/no): ");
                newCase = new OrphanedAnimalRescue(id, animalName, species, location, ranger, days, dailyCost, age, feedingCost, foster);
                break;
            case "3":
                String classification = getNonBlankInput("Enter Conservation Classification: ");
                double securityCost = getPositiveDoubleInput("Enter Security Cost (R): ");
                boolean specialist = getBooleanInput("Is specialist team required? (yes/no): ");
                newCase = new EndangeredSpeciesRescue(id, animalName, species, location, ranger, days, dailyCost, classification, securityCost, specialist);
                break;
            default:
                System.out.println("Invalid rescue type selection. Aborting case creation.");
                return;
        }

        if (manager.addRescueCase(newCase)) {
            System.out.println("Rescue Case created successfully with initial status 'Pending'!");
        } else {
            System.out.println("Error adding rescue case.");
        }
    }

    // Search case by ID and print summary
    private static void searchRescueCase() {
        System.out.println("\n--- Search Rescue Case ---");
        String id = getNonBlankInput("Enter Rescue Case ID to search: ");
        RescueCase rc = manager.searchRescueCase(id);
        if (rc != null) {
            System.out.println("\nCase Found:");
            System.out.println(rc.generateRescueSummary());
        } else {
            System.out.println("Rescue case with ID '" + id + "' not found.");
        }
    }

    // Progress tracking update using RescueOperation interface methods
    private static void updateRescueStatus() {
        System.out.println("\n--- Update Rescue Progress Status ---");
        String id = getNonBlankInput("Enter Rescue Case ID: ");
        RescueCase rc = manager.searchRescueCase(id);
        if (rc == null) {
            System.out.println("Rescue case not found.");
            return;
        }

        System.out.println("Current Rescue Status: [" + rc.getCurrentRescueStatus() + "]");
        System.out.println("Select New Progress Stage:");
        System.out.println("1. Start Operation (Set status -> 'Rescue in Progress')");
        System.out.println("2. Complete Operation (Set status -> 'Completed')");
        System.out.println("3. Set Custom Progress Note");
        System.out.print("Option: ");
        String choice = scanner.nextLine().trim();

        if (choice.equals("1")) {
            rc.startRescueOperation();
            System.out.println("Status updated to 'Rescue in Progress'.");
        } else if (choice.equals("2")) {
            rc.completeRescueOperation();
            System.out.println("Status updated to 'Completed'.");
        } else if (choice.equals("3")) {
            String customStatus = getNonBlankInput("Enter custom status description: ");
            rc.setCurrentRescueStatus(customStatus);
            System.out.println("Status updated successfully.");
        } else {
            System.out.println("Invalid choice.");
        }
    }

    // Displays summary of all cases currently recorded
    private static void displayAllCases() {
        System.out.println("\n--- All Rescue Cases ---");
        if (manager.getRescueCases().isEmpty()) {
            System.out.println("No cases recorded.");
            return;
        }
        for (RescueCase rc : manager.getRescueCases()) {
            System.out.println(rc.generateRescueSummary());
            System.out.println("--------------------------------------------------");
        }
    }

    // Filter and display rescue cases by progress status
    private static void filterCasesByProgress() {
        System.out.println("\n--- Progress Tracker: Filter Cases ---");
        System.out.println("Select Status Stage to Filter:");
        System.out.println("1. Pending");
        System.out.println("2. Rescue in Progress");
        System.out.println("3. Completed");
        System.out.print("Select choice (1-3): ");
        String choice = scanner.nextLine().trim();

        String targetStatus = "";
        if (choice.equals("1")) {
            targetStatus = "Pending";
        } else if (choice.equals("2")) {
            targetStatus = "Rescue in Progress";
        } else if (choice.equals("3")) {
            targetStatus = "Completed";
        } else {
            System.out.println("Invalid option.");
            return;
        }

        System.out.println("\n--- Cases with Status: '" + targetStatus + "' ---");
        boolean found = false;
        for (RescueCase rc : manager.getRescueCases()) {
            if (rc.getCurrentRescueStatus().equalsIgnoreCase(targetStatus)) {
                System.out.println(rc.generateRescueSummary());
                System.out.println("--------------------------------------------------");
                found = true;
            }
        }
        if (!found) {
            System.out.println("No cases found with status '" + targetStatus + "'.");
        }
    }

    // Helper method to ensure user enters non-blank text
    private static String getNonBlankInput(String prompt) {
        String input = "";
        while (input.isBlank()) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (input.isBlank()) {
                System.out.println("Error: Input cannot be blank. Please try again.");
            }
        }
        return input;
    }

    // Helper method to validate positive integer entries
    private static int getPositiveIntInput(String prompt) {
        int val = -1;
        while (val <= 0) {
            System.out.print(prompt);
            try {
                val = Integer.parseInt(scanner.nextLine().trim());
                if (val <= 0) {
                    System.out.println("Error: Number must be greater than zero.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid numeric entry.");
            }
        }
        return val;
    }

    // Helper method to validate positive double entries
    private static double getPositiveDoubleInput(String prompt) {
        double val = -1;
        while (val <= 0) {
            System.out.print(prompt);
            try {
                val = Double.parseDouble(scanner.nextLine().trim());
                if (val <= 0) {
                    System.out.println("Error: Value must be greater than zero.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid numeric entry.");
            }
        }
        return val;
    }

    // Helper method to validate yes/no boolean input
    private static boolean getBooleanInput(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim().toLowerCase();
            if (input.equals("yes") || input.equals("y") || input.equals("true")) {
                return true;
            } else if (input.equals("no") || input.equals("n") || input.equals("false")) {
                return false;
            } else {
                System.out.println("Error: Please enter 'yes' or 'no'.");
            }
        }
    }
}
