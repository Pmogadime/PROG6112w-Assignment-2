/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

/**
 *
 * @author prude
 */

// Subclass for managing injured animal rescue cases
public class InjuredAnimalRescue extends RescueCase {

    // Specific attributes for medical care
    private String injuryDescription;
    private double veterinaryCost;
    private boolean surgeryRequired;

    // Constructor initializing shared and subclass attributes
    public InjuredAnimalRescue(String rescueCaseId, String animalName, String species, 
                               String rescueLocation, String assignedRanger, 
                               int numberOfRescueDays, double dailyCareCost, 
                               String injuryDescription, double veterinaryCost, 
                               boolean surgeryRequired) {
        super(rescueCaseId, animalName, species, rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
        this.injuryDescription = injuryDescription;
        this.veterinaryCost = veterinaryCost;
        this.surgeryRequired = surgeryRequired;
    }

    // Calculates base care cost + vet fees + optional R2,500 surgery fee
    @Override
    public double calculateTotalRescueCost() {
        double baseCost = getNumberOfRescueDays() * getDailyCareCost();
        double extraSurgeryFee = surgeryRequired ? 2500.0 : 0.0;
        return baseCost + veterinaryCost + extraSurgeryFee;
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    // Assigns priority based on medical urgency and cost
    @Override
    public void determineRescuePriority() {
        if (surgeryRequired || veterinaryCost > 10000.0) {
            setRescuePriority("Critical");
        } else if (veterinaryCost > 3000.0) {
            setRescuePriority("High");
        } else {
            setRescuePriority("Medium");
        }
    }

    // Appends medical breakdown to the main summary
    @Override
    public String generateRescueSummary() {
        return super.generateRescueSummary() + String.format(
            "\nInjury         : %s" +
            "\nSurgery Needed : %s" +
            "\nVeterinary Cost: R%.2f" +
            "\nTotal Cost     : R%.2f",
            injuryDescription, (surgeryRequired ? "Yes" : "No"), veterinaryCost, calculateTotalRescueCost()
        );
    }

    // Getters
    public String getInjuryDescription() { return injuryDescription; }
    public double getVeterinaryCost() { return veterinaryCost; }
    public boolean isSurgeryRequired() { return surgeryRequired; }
}