/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;
import java.util.ArrayList;
/**
 *
 * @author prude
 */

public class RescueManager {

    // List storing all active rescue cases
    private ArrayList<RescueCase> rescueCases;

    // Constructor initializing empty ArrayList
    public RescueManager() {
        this.rescueCases = new ArrayList<>();
    }

    // Adds a case if valid and ID is unique
    public boolean addRescueCase(RescueCase rescueCase) {
        if (rescueCase == null || isIdDuplicate(rescueCase.getRescueCaseId())) {
            return false;
        }
        rescueCases.add(rescueCase);
        return true;
    }

    // Searches for a case matching given ID
    public RescueCase searchRescueCase(String rescueCaseId) {
        for (RescueCase rc : rescueCases) {
            if (rc.getRescueCaseId().equalsIgnoreCase(rescueCaseId)) {
                return rc; // Found
            }
        }
        return null; // Not found
    }

    // Helper method 
    public RescueCase findRescueCaseById(String rescueCaseId) {
        return searchRescueCase(rescueCaseId);
    }

    // Updates status for a specific case by ID
    public boolean updateRescueStatus(String rescueCaseId, String newStatus) {
        RescueCase rc = searchRescueCase(rescueCaseId);
        if (rc != null) {
            rc.setCurrentRescueStatus(newStatus);
            return true;
        }
        return false;
    }

    // Checks if an ID already exists in the list
    public boolean isIdDuplicate(String rescueCaseId) {
        return searchRescueCase(rescueCaseId) != null;
    }

    // Calculates total cost across all stored rescue cases
    public double calculateTotalRescueCostAllCases() {
        double total = 0;
        for (RescueCase rc : rescueCases) {
            total += rc.calculateTotalRescueCost();
        }
        return total;
    }

    // Gets total number of recorded cases
    public int getCaseCount() {
        return rescueCases.size();
    }

    // Returns full ArrayList of rescue cases
    public ArrayList<RescueCase> getRescueCases() {
        return rescueCases;
    }

    // Generates complete output report string for all cases
    public String generateFullReport() {
        if (rescueCases.isEmpty()) {
            return "No rescue cases currently registered.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("==================================================\n");
        sb.append("WILDLIFE RESCUE REPORT\n");
        sb.append("==================================================\n\n");

        for (RescueCase rc : rescueCases) {
            rc.determineRescuePriority();
            sb.append("Case ID        : ").append(rc.getRescueCaseId()).append("\n");
            sb.append("Type           : ").append(rc.getRescueType()).append("\n");
            sb.append("Species        : ").append(rc.getSpecies()).append("\n");
            sb.append("Location       : ").append(rc.getRescueLocation()).append("\n");
            sb.append("Assigned Ranger: ").append(rc.getAssignedRanger()).append("\n");
            sb.append("Priority       : ").append(rc.getRescuePriority()).append("\n");
            sb.append("Status         : ").append(rc.getCurrentRescueStatus()).append("\n");
            sb.append(String.format("Total Cost     : R%.2f\n", rc.calculateTotalRescueCost()));
            sb.append("--------------------------------------------------\n");
        }

        sb.append(String.format("Total Rescue Cases : %d\n", getCaseCount()));
        sb.append(String.format("Total Rescue Cost  : R%.2f\n", calculateTotalRescueCostAllCases()));
        sb.append("==================================================\n");

        return sb.toString();
    }
}