/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



/**
 *JUnit 5 Test for Wildlife Rescue Operations System.
 * Tests class constructors, cost calculations, priority rules,
 * status changes, duplicate ID checking, and search logic.
 * 
 * @author prude
 */
// JUnit 5 unit tests
public class WildlifeRescueOperationTest {
    private RescueManager manager;
    private InjuredAnimalRescue injuredCase;
    private OrphanedAnimalRescue orphanedCase;
    private EndangeredSpeciesRescue endangeredCase;

    // Set up test objects before each test execution
    @BeforeEach
    public void setUp() {
        manager = new RescueManager();
        injuredCase = new InjuredAnimalRescue("RC001", "Leo", "Lion", "Kruger National Park", "Ranger John", 5, 500.0, "Broken Leg", 3000.0, true);
        orphanedCase = new OrphanedAnimalRescue("RC002", "Ellie", "Elephant", "Addo Elephant Park", "Ranger Mary", 10, 300.0, 2, 1500.0, true);
        endangeredCase = new EndangeredSpeciesRescue("RC003", "Rhino", "Black Rhino", "Pilanesberg Park", "Ranger David", 7, 1000.0, "Critically Endangered", 5000.0, true);
    }

    // Test for rescue cost calculations
    @Test
    public void testRescueCostCalculations_InjuredAnimal() {
        // Base cost: 5 days * 500.0 = 2500.0
        // Additional: 3000.0 vet + 5000.0 surgery = 8000.0
        // Total expected: 10500.0
        assertEquals(10500.0, injuredCase.calculateTotalCost(), 0.001);
    }

    @Test
    public void testRescueCostCalculations_OrphanedAnimal() {
        // Base cost: 10 days * 300.0 = 3000.0
        // Additional: 1500.0 feeding + 2500.0 foster care = 4000.0
        // Total expected: 7000.0
        assertEquals(7000.0, orphanedCase.calculateTotalCost(), 0.001);
    }

    @Test
    public void testRescueCostCalculations_EndangeredSpecies() {
        // Base cost: 7 days * 1000.0 = 7000.0
        // Additional: 5000.0 security + 8000.0 specialist team = 13000.0
        // Total expected: 20000.0
        assertEquals(20000.0, endangeredCase.calculateTotalCost(), 0.001);
    }

    //Rescue priority calculations
    @Test
    public void testRescuePriorityCalculation_InjuredRequiresSurgery_ReturnsCritical() {
        assertEquals(RescuePriority.CRITICAL, injuredCase.calculatePriority());
    }

    @Test
    public void testRescuePriorityCalculation_OrphanedYoungAge_ReturnsHigh() {
        assertEquals(RescuePriority.HIGH, orphanedCase.calculatePriority());
    }

    @Test
    public void testRescuePriorityCalculation_EndangeredCriticallyEndangered_ReturnsCritical() {
        assertEquals(RescuePriority.CRITICAL, endangeredCase.calculatePriority());
    }

    //Rescue status updates
    @Test
    public void testRescueStatusUpdates_StartAndCompleteWorkflow() {
        assertEquals(RescueStatus.REPORTED, injuredCase.getStatus());

        injuredCase.startRescue();
        assertEquals(RescueStatus.IN_PROGRESS, injuredCase.getStatus());

        injuredCase.completeRescue();
        assertEquals(RescueStatus.COMPLETED, injuredCase.getStatus());
    }

    @Test
    public void testRescueStatusUpdates_ManualSetStatus() {
        injuredCase.setStatus(RescueStatus.IN_PROGRESS);
        assertEquals(RescueStatus.IN_PROGRESS, injuredCase.getStatus());
    }

    //Searching for an existing rescue case
    @Test
    public void testSearchingExistingRescueCase_Found() {
        manager.addCase(injuredCase);
        RescueCase result = manager.findById("RC001");
        assertNotNull(result);
        assertEquals("RC001", result.getCaseId());
        assertEquals("Leo", result.getAnimalName());
    }

    @Test
    public void testSearchingExistingRescueCase_NotFound() {
        manager.addCase(injuredCase);
        RescueCase result = manager.findById("NON_EXISTENT_ID");
        assertNull(result);
    }

    //Preventing duplicate Rescue Case IDs
    @Test
    public void testPreventingDuplicateRescueCaseIds_ThrowsException() {
        manager.addCase(injuredCase);
        
        // Attempting to add duplicate ID "RC001"
        InjuredAnimalRescue duplicateCase = new InjuredAnimalRescue("RC001", "Simba", "Lion", "Kruger National Park", "Ranger Sarah", 3, 400.0, "Minor Scratch", 1000.0, false);
        
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            manager.addCase(duplicateCase);
        });

        assertTrue(exception.getMessage().contains("already exists"));
    }
}