/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 *
 * @author prude
 */

// Manager class handling case records
public class RescueManager {
    // List storing registered rescue cases
    private final List rescueCases = new ArrayList<>();

    // Add new case with duplicate ID guard
    public void addCase(RescueCase rescueCase) {
        if (rescueCase == null) {
            throw new IllegalArgumentException("Rescue case cannot be null.");
        }
        if (idExists(rescueCase.getCaseId())) {
            throw new IllegalArgumentException("A rescue case with ID '" + rescueCase.getCaseId() + "' already exists.");
        }
        rescueCases.add(rescueCase);
    }

    // Find case by ID
    public RescueCase findById(String caseId) {
        if (caseId == null || caseId.isBlank()) return null;
        for (Object obj : rescueCases) {
            RescueCase rescueCase = (RescueCase) obj;
            if (rescueCase.getCaseId().equalsIgnoreCase(caseId.trim())) {
                return rescueCase;
            }
        }
        return null;
    }

    // Check if ID already exists
    public boolean idExists(String caseId) {
        return findById(caseId) != null;
    }

    // Return unmodifiable list of cases
    public List getAllCases() {
        return Collections.unmodifiableList(rescueCases);
    }

    // Count of stored cases
    public int getCaseCount() {
        return rescueCases.size();
    }

    // Total cost calculation across all cases
    public double getTotalEstimatedCost() {
        double total = 0.0;
        for (Object obj : rescueCases) {
            RescueCase rescueCase = (RescueCase) obj;
            total += rescueCase.calculateTotalCost();
        }
        return total;
    }

    // Build overall system summary report
    public String generateReport() {
        if (rescueCases.isEmpty()) {
            return "No rescue cases currently recorded.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("===== WILDLIFE RESCUE OPERATIONS REPORT =====\n\n");
        for (Object obj : rescueCases) {
            RescueCase rescueCase = (RescueCase) obj;
            sb.append(rescueCase.generateSummary()).append("\n");
        }
        sb.append(String.format("\nTotal Registered Cases: %d", getCaseCount()));
        sb.append(String.format("\nTotal Operations Cost: R %.2f", getTotalEstimatedCost()));
        return sb.toString();
    }
}