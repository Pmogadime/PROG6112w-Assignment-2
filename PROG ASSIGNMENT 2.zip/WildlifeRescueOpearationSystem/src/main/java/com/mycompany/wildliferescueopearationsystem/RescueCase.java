/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * @author prude
 * Abstract base class serving as the core foundation for all wildlife rescue types.
 */

// Abstract base class for all rescue cases
public abstract class RescueCase implements RescueOperation {
    private final String caseId;
    private final String animalName;
    private final String species;
    private final String rescueLocation;
    private final String assignedRanger;
    private final int numberOfRescueDays;
    private final double dailyCareCost;
    private RescueStatus status;

    // Constructor with input checks
    public RescueCase(String caseId, String animalName, String species, String rescueLocation, 
                      String assignedRanger, int numberOfRescueDays, double dailyCareCost) {
        this.caseId = requireText(caseId, "Case ID");
        this.animalName = (animalName == null || animalName.isBlank()) ? "Unnamed" : animalName.trim();
        this.species = requireText(species, "Species");
        this.rescueLocation = requireText(rescueLocation, "Rescue location");
        this.assignedRanger = requireText(assignedRanger, "Assigned ranger");
        this.numberOfRescueDays = requirePositive(numberOfRescueDays, "Number of rescue days");
        this.dailyCareCost = requirePositive(dailyCareCost, "Daily care cost");
        this.status = RescueStatus.REPORTED;
    }

    // Validation helpers
    public static String requireText(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank.");
        }
        return value.trim();
    }

    public static int requirePositive(int value, String fieldName) {
        if (value <= 0) {
            throw new IllegalArgumentException(fieldName + " must be greater than zero.");
        }
        return value;
    }

    public static double requirePositive(double value, String fieldName) {
        if (value <= 0 || Double.isNaN(value) || Double.isInfinite(value)) {
            throw new IllegalArgumentException(fieldName + " must be a valid positive number.");
        }
        return value;
    }

    // Getters and setters
    public String getCaseId() { return caseId; }
    public String getAnimalName() { return animalName; }
    public String getSpecies() { return species; }
    public String getRescueLocation() { return rescueLocation; }
    public String getAssignedRanger() { return assignedRanger; }
    public int getNumberOfRescueDays() { return numberOfRescueDays; }
    public double getDailyCareCost() { return dailyCareCost; }
    public RescueStatus getStatus() { return status; }

    public void setStatus(RescueStatus status) {
        if (status == null) throw new IllegalArgumentException("Status cannot be null.");
        this.status = status;
    }

    // Base cost calculation
    public double calculateBaseCareCost() {
        return numberOfRescueDays * dailyCareCost;
    }

    // Abstract methods for subclasses
    public abstract double calculateAdditionalCosts();
    public abstract RescuePriority calculatePriority();
    public abstract String getSpecificTypeLabel();

    // Total cost formula
    public double calculateTotalCost() {
        return calculateBaseCareCost() + calculateAdditionalCosts();
    }

    // Interface methods implementation
    @Override
    public void startRescue() {
        if (status == RescueStatus.COMPLETED) {
            throw new IllegalStateException("Cannot start a case that is already completed.");
        }
        this.status = RescueStatus.IN_PROGRESS;
    }

    @Override
    public void completeRescue() {
        if (status == RescueStatus.REPORTED) {
            throw new IllegalStateException("Cannot complete a case before starting it.");
        }
        this.status = RescueStatus.COMPLETED;
    }

    @Override
    public String generateSummary() {
        return String.format("[%s] ID: %s | %s (%s) | Status: %s | Priority: %s | Total Cost: %s",
                getSpecificTypeLabel(), caseId, animalName, species, status, calculatePriority(), formatMoney(calculateTotalCost()));
    }

    // Currency formatter for ZAR (uses modern Locale.of to clear deprecation warning)
    protected String formatMoney(double amount) {
        return NumberFormat.getCurrencyInstance(Locale.of("en", "ZA")).format(amount);
    }

    @Override
    public String toString() {
        return String.format("""
                Case ID: %s
                Type: %s
                Animal Name: %s
                Species: %s
                Location: %s
                Assigned Ranger: %s
                Status: %s
                Priority: %s
                Rescue Days: %d
                Daily Care Cost: %s
                Base Care Cost: %s
                Additional Costs: %s
                Total Estimated Cost: %s""",
                caseId, getSpecificTypeLabel(), animalName, species, rescueLocation, assignedRanger,
                status, calculatePriority(), numberOfRescueDays, formatMoney(dailyCareCost),
                formatMoney(calculateBaseCareCost()), formatMoney(calculateAdditionalCosts()),
                formatMoney(calculateTotalCost()));
    }
}