/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

/**
 * @author prude
 * 
 */

// Enum for tracking rescue case status
public enum RescueStatus {
    REPORTED,
    IN_PROGRESS,
    COMPLETED
}

