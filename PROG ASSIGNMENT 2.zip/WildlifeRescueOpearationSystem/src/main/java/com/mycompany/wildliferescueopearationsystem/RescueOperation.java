/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

/**
 *
 * @author prude
*/

// Operational interface for rescue actions
public interface RescueOperation {
    void startRescue();
    void completeRescue();
    String generateSummary();
}

