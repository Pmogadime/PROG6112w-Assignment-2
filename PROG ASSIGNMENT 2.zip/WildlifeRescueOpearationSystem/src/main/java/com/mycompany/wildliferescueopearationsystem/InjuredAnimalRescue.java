/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

/**
 *
 * @author prude
 */

// Subclass for managing injured animal rescue cases
public class InjuredAnimalRescue extends RescueCase {
    public static final double SURGERY_FEE = 5000.0;
    public static final double HIGH_VET_COST_THRESHOLD = 10000.0;

    private final String injuryDescription;
    private final double veterinaryCost;
    private final boolean requiresSurgery;

    public InjuredAnimalRescue(String caseId, String animalName, String species, String rescueLocation,
                               String assignedRanger, int numberOfRescueDays, double dailyCareCost,
                               String injuryDescription, double veterinaryCost, boolean requiresSurgery) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
        this.injuryDescription = requireText(injuryDescription, "Injury description");
        this.veterinaryCost = requirePositive(veterinaryCost, "Veterinary treatment cost");
        this.requiresSurgery = requiresSurgery;
    }

    public String getInjuryDescription() { return injuryDescription; }
    public double getVeterinaryCost() { return veterinaryCost; }
    public boolean isRequiresSurgery() { return requiresSurgery; }

    // Adds vet cost and surgery fee if needed
    @Override
    public double calculateAdditionalCosts() {
        return veterinaryCost + (requiresSurgery ? SURGERY_FEE : 0.0);
    }

    // Evaluates priority based on surgery and cost
    @Override
    public RescuePriority calculatePriority() {
        if (requiresSurgery) return RescuePriority.CRITICAL;
        if (veterinaryCost >= HIGH_VET_COST_THRESHOLD) return RescuePriority.HIGH;
        return RescuePriority.MEDIUM;
    }

    @Override
    public String getSpecificTypeLabel() {
        return "Injured Animal";
    }

    @Override
    public String toString() {
        return super.toString() + String.format("""
                
                Injury Description: %s
                Veterinary Cost: %s
                Surgery Required: %s""",
                injuryDescription, formatMoney(veterinaryCost), requiresSurgery ? "Yes" : "No");
    }
}