/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

/**
 *
 * @author prude
 */
  
// Subclass for managing endangered species protection cases
public class EndangeredSpeciesRescue extends RescueCase {
    public static final double SPECIALIST_TEAM_FEE = 8000.0;

    private final String conservationStatus;
    private final double securityCost;
    private final boolean requiresSpecialistTeam;

    public EndangeredSpeciesRescue(String caseId, String animalName, String species, String rescueLocation,
                                   String assignedRanger, int numberOfRescueDays, double dailyCareCost,
                                   String conservationStatus, double securityCost, boolean requiresSpecialistTeam) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
        this.conservationStatus = requireText(conservationStatus, "Conservation classification");
        this.securityCost = requirePositive(securityCost, "Security cost");
        this.requiresSpecialistTeam = requiresSpecialistTeam;
    }

    public String getConservationStatus() { return conservationStatus; }
    public double getSecurityCost() { return securityCost; }
    public boolean isRequiresSpecialistTeam() { return requiresSpecialistTeam; }

    // Adds security cost and specialist team fee if needed
    @Override
    public double calculateAdditionalCosts() {
        return securityCost + (requiresSpecialistTeam ? SPECIALIST_TEAM_FEE : 0.0);
    }

    // Evaluates priority based on species threat level
    @Override
    public RescuePriority calculatePriority() {
        if (requiresSpecialistTeam || conservationStatus.equalsIgnoreCase("Critically Endangered")) {
            return RescuePriority.CRITICAL;
        }
        return RescuePriority.HIGH;
    }

    @Override
    public String getSpecificTypeLabel() {
        return "Endangered Species";
    }

    @Override
    public String toString() {
        return super.toString() + String.format("""
                
                Conservation Classification: %s
                Security Cost: %s
                Specialist Team Required: %s""",
                conservationStatus, formatMoney(securityCost), requiresSpecialistTeam ? "Yes" : "No");
    }
}