/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

/**
 * @author prude 
 * Enumeration defining urgency levels for dispatching response teams and prioritizing care.
 * Automatically evaluated based on medical severity, age, or species endangerment status.
 */

// Enum for urgency levels
public enum RescuePriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

