/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.wildliferescueopearationsystem;
 import java.util.Scanner;

/**
 *
 * @author prude
 */
// Main entry point class managing user interactions and menu prompts
public class WildlifeRescueOperationSystem {
    private static final Scanner in = new Scanner(System.in);
    private static final RescueManager manager = new RescueManager();

    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            printMenu();
            switch (readInt("Enter choice: ", 1, 9)) {
                case 1 -> createCase();
                case 2 -> searchCase();
                case 3 -> updateStatus();
                case 4 -> displayAll();
                case 5 -> operate("start");
                case 6 -> operate("complete");
                case 7 -> operate("summary");
                case 8 -> System.out.println(manager.generateReport());
                case 9 -> { running = false; System.out.println("Goodbye."); }
            }
        }
    }

    // Display main menu options
    private static void printMenu() {
        System.out.println("\n===== WildLife SA Rescue Operations =====");
        System.out.println("1. Create new rescue case");
        System.out.println("2. Search rescue case by ID");
        System.out.println("3. Update rescue status");
        System.out.println("4. Display all rescue cases");
        System.out.println("5. Start rescue operation");
        System.out.println("6. Complete rescue operation");
        System.out.println("7. Generate rescue summary");
        System.out.println("8. Generate rescue report");
        System.out.println("9. Exit");
    }

    // Menu option 1: Create a new rescue case
    private static void createCase() {
        System.out.println("\nRescue type: 1. Injured  2. Orphaned  3. Endangered Species");
        int type = readInt("Select type: ", 1, 3);

        String id;
        while (true) {
            id = readText("Rescue Case ID: ");
            if (manager.idExists(id)) System.out.println("Error: that Rescue Case ID already exists.");
            else break;
        }
        System.out.print("Animal Name (optional): ");
        String name = in.nextLine();
        String species = readText("Species: ");
        String location = readText("Rescue Location: ");
        String ranger = readText("Assigned Ranger: ");
        int days = readInt("Number of Rescue Days: ", 1, Integer.MAX_VALUE);
        double daily = readPositiveDouble("Daily Care Cost (R): ");

        RescueCase rc;
        switch (type) {
            case 1 -> rc = new InjuredAnimalRescue(id, name, species, location, ranger, days, daily,
                    readText("Injury Description: "),
                    readPositiveDouble("Veterinary Treatment Cost (R): "),
                    readYesNo("Surgery required?"));
            case 2 -> rc = new OrphanedAnimalRescue(id, name, species, location, ranger, days, daily,
                    readInt("Estimated Age (months): ", 1, Integer.MAX_VALUE),
                    readPositiveDouble("Feeding Cost (R): "),
                    readYesNo("Foster care required?"));
            default -> rc = new EndangeredSpeciesRescue(id, name, species, location, ranger, days, daily,
                    readText("Conservation Classification: "),
                    readPositiveDouble("Security Cost (R): "),
                    readYesNo("Specialist team required?"));
        }
        manager.addCase(rc);
        System.out.println("Rescue case created successfully.");
    }

    // Menu option 2: Search case by ID
    private static void searchCase() {
        RescueCase rescueCase = manager.findById(readText("Rescue Case ID to search: "));
        System.out.println(rescueCase == null ? "No rescue case found with that ID." : rescueCase);
    }

    // Menu option 3: Update case status
    private static void updateStatus() {
        RescueCase rescueCase = manager.findById(readText("Rescue Case ID: "));
        if (rescueCase == null) { System.out.println("No rescue case found with that ID."); return; }
        System.out.println("Current status: " + rescueCase.getStatus());
        System.out.println("1. Reported  2. In Progress  3. Completed");
        int choice = readInt("New status: ", 1, 3);
        rescueCase.setStatus(RescueStatus.values()[choice - 1]);
        System.out.println("Status updated to: " + rescueCase.getStatus());
    }

    // Menu option 4: Display all cases
    private static void displayAll() {
        if (manager.getCaseCount() == 0) {
            System.out.println("No rescue cases recorded.");
            return;
        }
        for (Object obj : manager.getAllCases()) {
            RescueCase rescueCase = (RescueCase) obj;
            System.out.println(rescueCase);
            System.out.println();
        }
    }

    // Menu options 5-7: Execute operational action
    private static void operate(String action) {
        RescueCase rescueCase = manager.findById(readText("Rescue Case ID: "));
        if (rescueCase == null) { System.out.println("No rescue case found with that ID."); return; }
        try {
            switch (action) {
                case "start" -> { rescueCase.startRescue(); System.out.println("Rescue started. Status: " + rescueCase.getStatus()); }
                case "complete" -> { rescueCase.completeRescue(); System.out.println("Rescue completed. Status: " + rescueCase.getStatus()); }
                default -> System.out.println(rescueCase.generateSummary());
            }
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Prompt for non-empty text input
    private static String readText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = in.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Error: this field cannot be blank.");
        }
    }

    // Prompt for integer within range
    private static int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            try {
                int v = Integer.parseInt(in.nextLine().trim());
                if (v >= min && v <= max) return v;
            } catch (NumberFormatException ignored) { }
            System.out.println(max == Integer.MAX_VALUE
                    ? "Error: enter a whole number of at least " + min + "."
                    : "Error: enter a number between " + min + " and " + max + ".");
        }
    }

    // Prompt for positive decimal number
    private static double readPositiveDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double v = Double.parseDouble(in.nextLine().trim());
                if (v > 0 && !Double.isInfinite(v)) return v;
            } catch (NumberFormatException ignored) { }
            System.out.println("Error: enter a number greater than zero.");
        }
    }

    // Prompt for boolean Y/N input
    private static boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt + " (Y/N): ");
            String s = in.nextLine().trim();
            if (s.equalsIgnoreCase("Y")) return true;
            if (s.equalsIgnoreCase("N")) return false;
            System.out.println("Error: enter Y or N.");
        }
    }
}