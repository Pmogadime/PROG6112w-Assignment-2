/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescueopearationsystem;

/**
 *
 * @author prude
 */

// Subclass for managing orphaned animal rescue case
public class OrphanedAnimalRescue extends RescueCase {
    public static final double FOSTER_CARE_FEE = 2500.0;

    private final int estimatedAgeMonths;
    private final double feedingCost;
    private final boolean requiresFosterCare;

    public OrphanedAnimalRescue(String caseId, String animalName, String species, String rescueLocation,
                                String assignedRanger, int numberOfRescueDays, double dailyCareCost,
                                int estimatedAgeMonths, double feedingCost, boolean requiresFosterCare) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
        this.estimatedAgeMonths = requirePositive(estimatedAgeMonths, "Estimated age in months");
        this.feedingCost = requirePositive(feedingCost, "Feeding cost");
        this.requiresFosterCare = requiresFosterCare;
    }

    public int getEstimatedAgeMonths() { return estimatedAgeMonths; }
    public double getFeedingCost() { return feedingCost; }
    public boolean isRequiresFosterCare() { return requiresFosterCare; }

    // Adds feeding cost and foster care fee if needed
    @Override
    public double calculateAdditionalCosts() {
        return feedingCost + (requiresFosterCare ? FOSTER_CARE_FEE : 0.0);
    }

    // Evaluates priority based on age in months
    @Override
    public RescuePriority calculatePriority() {
        if (estimatedAgeMonths <= 3) return RescuePriority.HIGH;
        if (estimatedAgeMonths <= 12) return RescuePriority.MEDIUM;
        return RescuePriority.LOW;
    }

    @Override
    public String getSpecificTypeLabel() {
        return "Orphaned Animal";
    }

    @Override
    public String toString() {
        return super.toString() + String.format("""
                
                Estimated Age: %d months
                Feeding Cost: %s
                Foster Care Required: %s""",
                estimatedAgeMonths, formatMoney(feedingCost), requiresFosterCare ? "Yes" : "No");
    }
}